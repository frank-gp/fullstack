require("dotenv").config();

const mongoose = require("mongoose");


const MONGO_URI = process.env.MONGO_URI
const database = "moviesdatabase"
const url = MONGO_URI + database





const conDb = async ()=>{
    try{
        await mongoose.connect(url);
        console.log("se conecto");

    }
    catch (error){
        console.log(error);
    }
   
};

module.exports = conDb;
