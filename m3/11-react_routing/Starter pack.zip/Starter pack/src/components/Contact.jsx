function Contact({contact}) {
  return (
    <div>
      <h3>{contact.name}</h3>
    </div>
  );
}

export default Contact;
