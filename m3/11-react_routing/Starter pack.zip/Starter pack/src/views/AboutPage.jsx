function AboutPage() {
  return (
    <div>
      <h1>About Page</h1>
      <p>
        Esta es una página de prueba para el curso de React Routing del M3 de
        Henry.
      </p>
    </div>
  );
}

export default AboutPage;
